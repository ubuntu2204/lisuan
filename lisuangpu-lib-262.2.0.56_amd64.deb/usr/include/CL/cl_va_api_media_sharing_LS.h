
#ifndef __OPENCL_CL_VA_API_MEDIA_SHARING_LS_H
#define __OPENCL_CL_VA_API_MEDIA_SHARING_LS_H

#include <CL/cl.h>
#include <CL/cl_platform.h>
#include <va/va.h>

#ifdef __cplusplus
extern "C" {
#endif

/******************************************
* cl_LS_va_api_media_sharing extension *
*******************************************/

#define cl_LS_va_api_media_sharing 1

/* error codes */
#define CL_INVALID_VA_API_MEDIA_ADAPTER_LS               -1098
#define CL_INVALID_VA_API_MEDIA_SURFACE_LS               -1099
#define CL_VA_API_MEDIA_SURFACE_ALREADY_ACQUIRED_LS      -1100
#define CL_VA_API_MEDIA_SURFACE_NOT_ACQUIRED_LS          -1101

/* cl_va_api_device_source_LS */
#define CL_VA_API_DISPLAY_LS                             0x4094

/* cl_va_api_device_set_LS */
#define CL_PREFERRED_DEVICES_FOR_VA_API_LS               0x4095
#define CL_ALL_DEVICES_FOR_VA_API_LS                     0x4096

/* cl_context_info */
#define CL_CONTEXT_VA_API_DISPLAY_LS                     0x4097

/* cl_mem_info */
#define CL_MEM_VA_API_MEDIA_SURFACE_LS                   0x4098

/* cl_image_info */
#define CL_IMAGE_VA_API_PLANE_LS                         0x4099

/* cl_command_type */
#define CL_COMMAND_ACQUIRE_VA_API_MEDIA_SURFACES_LS      0x409A
#define CL_COMMAND_RELEASE_VA_API_MEDIA_SURFACES_LS      0x409B

typedef cl_uint cl_va_api_device_source_LS;
typedef cl_uint cl_va_api_device_set_LS;

extern CL_API_ENTRY cl_int CL_API_CALL
clGetDeviceIDsFromVAAPIMediaAdapterLS(
    cl_platform_id                platform,
    cl_va_api_device_source_LS media_adapter_type,
    void*                         media_adapter,
    cl_va_api_device_set_LS    media_adapter_set,
    cl_uint                       num_entries,
    cl_device_id*                 devices,
    cl_uint*                      num_devices) CL_API_SUFFIX__VERSION_1_2;

typedef CL_API_ENTRY cl_int (CL_API_CALL * clGetDeviceIDsFromVAAPIMediaAdapterLS_fn)(
    cl_platform_id                platform,
    cl_va_api_device_source_LS media_adapter_type,
    void*                         media_adapter,
    cl_va_api_device_set_LS    media_adapter_set,
    cl_uint                       num_entries,
    cl_device_id*                 devices,
    cl_uint*                      num_devices) CL_API_SUFFIX__VERSION_1_2;

extern CL_API_ENTRY cl_mem CL_API_CALL
clCreateFromVAAPIMediaSurfaceLS(
    cl_context                    context,
    cl_mem_flags                  flags,
    VASurfaceID*                  surface,
    cl_uint                       plane,
    cl_int*                       errcode_ret) CL_API_SUFFIX__VERSION_1_2;

typedef CL_API_ENTRY cl_mem (CL_API_CALL * clCreateFromVAAPIMediaSurfaceLS_fn)(
    cl_context                    context,
    cl_mem_flags                  flags,
    VASurfaceID*                  surface,
    cl_uint                       plane,
    cl_int*                       errcode_ret) CL_API_SUFFIX__VERSION_1_2;

extern CL_API_ENTRY cl_int CL_API_CALL
clEnqueueAcquireVAAPIMediaSurfacesLS(
    cl_command_queue              command_queue,
    cl_uint                       num_objects,
    const cl_mem*                 mem_objects,
    cl_uint                       num_events_in_wait_list,
    const cl_event*               event_wait_list,
    cl_event*                     event) CL_API_SUFFIX__VERSION_1_2;

typedef CL_API_ENTRY cl_int (CL_API_CALL *clEnqueueAcquireVAAPIMediaSurfacesLS_fn)(
    cl_command_queue              command_queue,
    cl_uint                       num_objects,
    const cl_mem*                 mem_objects,
    cl_uint                       num_events_in_wait_list,
    const cl_event*               event_wait_list,
    cl_event*                     event) CL_API_SUFFIX__VERSION_1_2;

extern CL_API_ENTRY cl_int CL_API_CALL
clEnqueueReleaseVAAPIMediaSurfacesLS(
    cl_command_queue              command_queue,
    cl_uint                       num_objects,
    const cl_mem*                 mem_objects,
    cl_uint                       num_events_in_wait_list,
    const cl_event*               event_wait_list,
    cl_event*                     event) CL_API_SUFFIX__VERSION_1_2;

typedef CL_API_ENTRY cl_int (CL_API_CALL *clEnqueueReleaseVAAPIMediaSurfacesLS_fn)(
    cl_command_queue              command_queue,
    cl_uint                       num_objects,
    const cl_mem*                 mem_objects,
    cl_uint                       num_events_in_wait_list,
    const cl_event*               event_wait_list,
    cl_event*                     event) CL_API_SUFFIX__VERSION_1_2;

extern CL_API_ENTRY cl_int CL_API_CALL 
clGetSupportedVAAPIMediaSurfaceFormatsLS(
    cl_context                    context,
    cl_mem_flags                  flags,
    cl_mem_object_type            imageType,
    cl_uint                       plane,
    cl_uint                       numEntries,
    VAImageFormat                 *vaApiFormats,
    cl_uint                       *numImageFormats) CL_API_SUFFIX__VERSION_1_2;
    
typedef CL_API_ENTRY cl_int (CL_API_CALL *clGetSupportedVAAPIMediaSurfaceFormatsLS_fn)(
    cl_context                    context,
    cl_mem_flags                  flags,
    cl_mem_object_type            imageType,
    cl_uint                       plane,
    cl_uint                       numEntries,
    VAImageFormat*                vaApiFormats,
    cl_uint*                      numImageFormats) CL_API_SUFFIX__VERSION_1_2;

#ifdef __cplusplus
}
#endif

#endif

